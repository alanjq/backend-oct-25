<?php

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];

echo $nombre . "<br/>"; echo $apellido;

?>