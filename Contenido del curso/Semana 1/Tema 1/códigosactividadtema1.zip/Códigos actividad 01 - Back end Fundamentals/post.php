<?php
$busqueda = $_POST['busqueda'];

    echo $busqueda . "<br/>";
?>